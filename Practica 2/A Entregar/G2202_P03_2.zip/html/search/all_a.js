var searchData=
[
  ['params',['params',['../ejercicio4a_8c.html#ac8d4b7ef3bb36bb6a956ac657e9a0b8f',1,'params():&#160;ejercicio4a.c'],['../ejercicio4b_8c.html#ac8d4b7ef3bb36bb6a956ac657e9a0b8f',1,'params():&#160;ejercicio4b.c']]],
  ['pid',['pid',['../ejercicio8b_8c.html#af500917c052066b40cf47f96b43c607b',1,'ejercicio8b.c']]],
  ['pid_5fraiz',['pid_raiz',['../ejercicio8b_8c.html#a53c9354fdf7ea02f79040ba6430ecb7f',1,'ejercicio8b.c']]]
];
