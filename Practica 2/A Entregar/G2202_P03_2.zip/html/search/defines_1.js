var searchData=
[
  ['num_5fhil',['NUM_HIL',['../ejercicio3b_8c.html#a1541b4eafb644db053370db475c0ea71',1,'ejercicio3b.c']]],
  ['num_5fproc',['NUM_PROC',['../ejercicio3a_8c.html#acee2369f62e4a096d243dec3cd7d0b00',1,'ejercicio3a.c']]],
  ['numpalabras',['NUMPALABRAS',['../ejercicio10_8c.html#a2b79500034922417daea33a4a20e4546',1,'ejercicio10.c']]]
];
