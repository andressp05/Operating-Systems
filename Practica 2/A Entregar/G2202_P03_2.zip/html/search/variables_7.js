var searchData=
[
  ['pid',['pid',['../ejercicio8b_8c.html#af500917c052066b40cf47f96b43c607b',1,'ejercicio8b.c']]],
  ['pid_5fraiz',['pid_raiz',['../ejercicio8b_8c.html#a53c9354fdf7ea02f79040ba6430ecb7f',1,'ejercicio8b.c']]]
];
