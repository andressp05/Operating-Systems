var searchData=
[
  ['is_5fprime',['is_prime',['../ejercicio3a_8c.html#af7397f188966cc18c1be25c8dad77bcb',1,'is_prime(int np):&#160;ejercicio3a.c'],['../ejercicio3b_8c.html#a3c96e5c70f817235701b2e9543215a1d',1,'is_prime(void *arg):&#160;ejercicio3b.c']]]
];
