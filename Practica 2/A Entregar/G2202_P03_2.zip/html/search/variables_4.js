var searchData=
[
  ['matriz',['matriz',['../struct__params.html#a04b3f21e1f7c21b17a510c2a4ee0e552',1,'_params']]],
  ['multiplicador',['multiplicador',['../struct__params.html#a142e538b8c88b8748ad390b6a86fe17d',1,'_params']]]
];
