var searchData=
[
  ['maxtam',['MAXTAM',['../ejercicio4a_8c.html#a0e68c4ad6b4b3a349afa80ebbbdffb13',1,'MAXTAM():&#160;ejercicio4a.c'],['../ejercicio4b_8c.html#a0e68c4ad6b4b3a349afa80ebbbdffb13',1,'MAXTAM():&#160;ejercicio4b.c']]]
];
