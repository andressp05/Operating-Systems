var searchData=
[
  ['params',['params',['../ejercicio4a_8c.html#ac8d4b7ef3bb36bb6a956ac657e9a0b8f',1,'params():&#160;ejercicio4a.c'],['../ejercicio4b_8c.html#ac8d4b7ef3bb36bb6a956ac657e9a0b8f',1,'params():&#160;ejercicio4b.c']]]
];
