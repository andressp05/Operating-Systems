var searchData=
[
  ['captura',['captura',['../ejercicio10_8c.html#a9f37a0f7ce38c68b8193b279dff1226b',1,'captura(int sig):&#160;ejercicio10.c'],['../ejercicio8_8c.html#a9f37a0f7ce38c68b8193b279dff1226b',1,'captura(int sig):&#160;ejercicio8.c']]],
  ['comprueba_5fmatriz',['comprueba_matriz',['../ejercicio4a_8c.html#af2eaee395141f1e236459336cbf0fdee',1,'comprueba_matriz(char *aux, int dim, int *matriz):&#160;ejercicio4a.c'],['../ejercicio4b_8c.html#af2eaee395141f1e236459336cbf0fdee',1,'comprueba_matriz(char *aux, int dim, int *matriz):&#160;ejercicio4b.c']]],
  ['cont',['cont',['../ejercicio8b_8c.html#a961800bf60ff693820efbf7f4bc72788',1,'ejercicio8b.c']]]
];
