var searchData=
[
  ['otrohilo',['otroHilo',['../struct__params.html#a21ba0961d6fcfa8c876ba58142d181be',1,'_params']]]
];
