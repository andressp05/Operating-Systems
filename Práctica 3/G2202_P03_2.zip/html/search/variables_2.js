var searchData=
[
  ['nombre',['nombre',['../structinfo.html#aaa02777b492865c2877852cb159803b1',1,'info']]]
];
