var searchData=
[
  ['datos',['datos',['../ejercicio2_8c.html#a1a7947f4bb22d269cbbdca314e89c2af',1,'ejercicio2.c']]]
];
