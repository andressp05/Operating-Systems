var searchData=
[
  ['n_5fsemaforos',['N_SEMAFOROS',['../ejercicio5_8c.html#a95c81905ff3d55e62fb763f407f9fab1',1,'N_SEMAFOROS():&#160;ejercicio5.c'],['../ejercicio5b_8c.html#a95c81905ff3d55e62fb763f407f9fab1',1,'N_SEMAFOROS():&#160;ejercicio5b.c']]],
  ['nombre',['nombre',['../structinfo.html#aaa02777b492865c2877852cb159803b1',1,'info']]]
];
