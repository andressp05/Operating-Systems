var searchData=
[
  ['info',['Info',['../ejercicio2_8c.html#a163511f3dadd6f89b69b2c2b6d40dcf7',1,'ejercicio2.c']]]
];
