var searchData=
[
  ['main',['main',['../ejercicio2_8c.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;ejercicio2.c'],['../ejercicio5_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ejercicio5.c'],['../ejercicio5b_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ejercicio5b.c'],['../ejercicio6_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ejercicio6.c']]]
];
