var searchData=
[
  ['id',['id',['../structinfo.html#afe86f23d8bd5fd8d139e39a5b1a01171',1,'info']]],
  ['info',['info',['../structinfo.html',1,'info'],['../ejercicio2_8c.html#a163511f3dadd6f89b69b2c2b6d40dcf7',1,'Info():&#160;ejercicio2.c']]],
  ['inicializar_5fsemaforo',['Inicializar_Semaforo',['../semaforos_8c.html#a4af104b0ed37e6ae0289a1059bc6e990',1,'semaforos.c']]]
];
