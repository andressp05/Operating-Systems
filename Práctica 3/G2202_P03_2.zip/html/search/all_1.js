var searchData=
[
  ['capturar',['capturar',['../ejercicio2_8c.html#a0ea23ff7004eb4a35a58394731fc9474',1,'ejercicio2.c']]],
  ['crear_5fsemaforo',['Crear_Semaforo',['../semaforos_8c.html#a16b16dd895b5f4cbe48f1ac8977e8b35',1,'semaforos.c']]]
];
