var searchData=
[
  ['down_5fsemaforo',['Down_Semaforo',['../semaforos_8c.html#a09cfe06b86766d42e1187644784afb9b',1,'semaforos.c']]],
  ['downmultiple_5fsemaforo',['DownMultiple_Semaforo',['../semaforos_8c.html#ad15a11016ff8903f5907773717c7d479',1,'semaforos.c']]]
];
